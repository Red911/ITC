Changes for 4.1.0

* Required Unity version changed to 2019.4
* Replaced gaze to object mapping system to G2OM
* Eye tracking settings menu is replaced with Tobii Initializer prefab
* Added Social sample with an avatar from ReadyPlayerMe
* Added Calibration sample
* Cleaned up the samples
* Changed release format from an Asset Package (.unitypackage) to a Unity Package Manager (UPM) release
* Samples are now imported using Unity Package Manager
* Ensured materials and shaders can be upgraded to work in URP
